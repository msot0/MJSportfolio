// ---------- SECTION NAV ----------
function showSection(id, el) {
  document.querySelectorAll(".content").forEach(section => {
    section.classList.add("hidden");
  });
  document.getElementById(id).classList.remove("hidden");

  document.querySelectorAll("nav li").forEach(li => li.classList.remove("active"));
  if (el) el.classList.add("active");

  const lookText = document.querySelector(".take-a-look");
  if (lookText) lookText.style.display = "none";

  window.scrollTo({ top: document.querySelector("nav").offsetTop, behavior: "smooth" });
}

// ---------- PARALLAX DOODLES ----------
const doodles = document.querySelectorAll(".doodle");

function updateParallax() {
  const scrollY = window.scrollY;
  doodles.forEach(el => {
    const speed = parseFloat(el.dataset.speed) || 0.2;
    el.style.transform = `translateY(${scrollY * speed}px) rotate(${scrollY * speed * 0.05}deg)`;
  });
}

let ticking = false;
window.addEventListener("scroll", () => {
  if (!ticking) {
    window.requestAnimationFrame(() => {
      updateParallax();
      ticking = false;
    });
    ticking = true;
  }
});
updateParallax();

// ---------- SCROLL REVEAL FOR PROJECT CARDS ----------
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("in-view");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll(".project").forEach(card => revealObserver.observe(card));
